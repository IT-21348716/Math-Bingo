import ReactDOM from 'react-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import HomeLinks from './HomeLinks';
import StartGame from './StartGame.js';
import CurrentLevelSingleton from './LevelSingleton';

export default function Level(){
    return(
        <div class="container w-50 p-3 my-5 bg-dark bg-opacity-25">
            <a className="btn btn-dark m-4 fs-2 fw-bold" style={{width:"200px"}} onClick={() => ReactDOM.render(<HomeLinks />, document.getElementById('Box'))}>Levels</a>
            <br/>
            <button className="btn btn-outline-dark btn-lg m-4 fw-bold" onClick={() => {
                    CurrentLevelSingleton.setLevel(1);
                    ReactDOM.render(<StartGame />, document.getElementById('Box'));
                }} style={{width:"150px"}}>
                Little
            </button><br/>
            <button className="btn btn-outline-dark btn-lg m-4 fw-bold" onClick={() => {
                    CurrentLevelSingleton.setLevel(2);
                    ReactDOM.render(<StartGame />, document.getElementById('Box'));
                }} style={{width:"150px"}}>
                Young
            </button><br/>
            <button className="btn btn-outline-dark btn-lg m-4 fw-bold" onClick={() => {
                    CurrentLevelSingleton.setLevel(3);
                    ReactDOM.render(<StartGame />, document.getElementById('Box'));
                }} style={{width:"150px"}}>
                Old
            </button>
            <br/><br/><br/>
        </div>
    );
}