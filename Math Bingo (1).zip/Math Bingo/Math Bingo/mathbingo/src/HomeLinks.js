import ReactDOM from 'react-dom';
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import Login from './Login';
import UserProfile from './UserProfile';
import Level from './Level';
import Leaderboard from './Leaderboard';

import Player from './Player';




export default function HomeLinks(){
    ReactDOM.render(<Player/>, document.getElementById('PlayerHere'));
    ReactDOM.render(<div></div>, document.getElementById('TimerHere'));
 
     
    return(
        <div class="container w-50 p-3 my-5 bg-dark bg-opacity-25">

            <button className="btn btn-outline-dark btn-lg m-2 fw-bold" onClick={() => ReactDOM.render(<UserProfile />, document.getElementById('Box'))} style={{width:"200px"}}>Profile</button><br/>
            <button className="btn btn-danger btn-lg m-2 fw-bold" onClick={() => ReactDOM.render(<Leaderboard />, document.getElementById('Box'))} style={{width:"200px"}}>Leaderboard</button><br/>

            <button className="btn btn-outline-dark btn-lg m-2 fw-bold" onClick={() => {
                ReactDOM.render(<Level />, document.getElementById('Box'));
                
            }} style={{width:"200px"}}>Start Game</button><br/>
            <button className="btn btn-danger btn-lg m-2 fw-bold" onClick={() => {
                ReactDOM.render(<div></div>, document.getElementById('PlayerHere')); 
                ReactDOM.render(<div></div>, document.getElementById('TimerHere'));
                ReactDOM.render(<Login />, document.getElementById('Box'));
            }} style={{width:"200px"}}>Logout</button><br/>
        </div>
    );
}