import logo from './logo.svg';
import './App.css';
import Home from './Home';
import backgroundImage from './background.jpg';

function App() {
  return (
    <div style={{ backgroundImage: `url(${backgroundImage})`}}>
      <br/><br/><br/>  
       
      <Home/>
      
    </div>
  );
}

export default App;
