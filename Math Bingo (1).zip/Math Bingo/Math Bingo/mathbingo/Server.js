const express = require('express');
const cors = require('cors');
const app = express();
const port = 3214;
const mongoose = require('mongoose');

app.use(cors());

app.use(express.json());

// mongoose.connect('mongodb+srv://Safna:cHmfJw5H9AjxwDqe@baby.muhsepp.mongodb.net/mathbingo', { useNewUrlParser: true, useUnifiedTopology: true })
mongoose.connect('mongodb+srv://suneru:IONxmktJAJRfmq0q@tomato.ba3axok.mongodb.net/TomatoDBsa', { useNewUrlParser: true, useUnifiedTopology: true })

.then(() => {
    console.log(' Current database:', mongoose.connection.db.databaseName);
})
.catch(err => console.log(err));

app.post('/Server/Register', async (req, res) => {
    let newUser = new User({
        UserID: req.body.UserID,
        Name: req.body.Name,
        Email: req.body.Email,
        Password: req.body.Password,
        Rank: req.body.Rank,
        BestTime: req.body.BestTime,
        GamesPlayed: req.body.GamesPlayed,
        GamesWon: req.body.GamesWon,
       
    });

    newUser.save()
    .then(savedUser => {
        console.log("User saved to collection:", savedUser);
        res.status(200).json(savedUser);
    })
    .catch(err => {
        console.error(err);
        console.log(" "+err);
        res.status(500).json({ error: err.toString() });
    });
});

let User = mongoose.model('User', new mongoose.Schema({
        UserID: Number,
        Name: String,
        Password: String,
        Email: String,
        Rank: Number,
        BestTime: Number,
        GamesPlayed: Number,
        GamesWon: Number
}));

app.get('/Server/UserProfile/:CurrentUserName', async (req, res) => {
    let CurrentUserName = req.params.CurrentUserName;
    console.log(CurrentUserName);
    User.findOne({ "Name": CurrentUserName })
    .then(user => {
        if (user) {
            console.log(user);
            console.log("USER IS  FOUND");
            res.json(user);
        } else {
            console.log("USER NOT FOUND");
            res.json(user);
        }
    })
    .catch(err => {
        let Dummy = {
                UserID: "000000",
                Name: "DUMMY",
                Email: "DUMMY",
                Password: "DUMMY",
                Rank: 0,
                BestTime: 60,
                GamesPlayed: 0,
                GamesWon: 0
        };
        res.json(Dummy);
        console.log(err);
    });
});

app.get('/Server/Leaderboard/:Rank', async (req, res) => {
    let Rank = req.params.Rank;
    console.log(Rank);
    User.findOne({ "Rank": Rank })
    .then(user => {
        if (user) {
            console.log(user);
            console.log("USER IS  FOUND");
            res.json(user);
        } else {
            console.log("USER NOT FOUND");
            res.json(user);
        }
    })
    .catch(err => {
        console.log(err);
    });
});

app.put('/Server/BestTime/:CurrentUserName', async (req, res) => {
    let CurrentUserName = req.params.CurrentUserName;
    let newBestTime = req.body.BestTime;
    User.findOneAndUpdate({ "Name": CurrentUserName }, { BestTime: newBestTime }, { new: true })
    .then(user => {
        console.log("TIME UPDATED");
    })
    .catch(err => {
        console.log(err);
    });
});

app.put('/Server/GamesPlayed/:CurrentUserName', async (req, res) => {
    let CurrentUserName = req.params.CurrentUserName;
    let newGamesPlayed = req.body.GamesPlayed;
    User.findOneAndUpdate({ "Name": CurrentUserName }, { GamesPlayed: newGamesPlayed }, { new: true })
    .then(user => {
        console.log("PLAYED UPDATED");
        res.json(user);
    })
    .catch(err => {
        console.log(err);
    });
});

app.put('/Server/GamesWon/:CurrentUserName', async (req, res) => {
    let CurrentUserName = req.params.CurrentUserName;
    let newGamesWon = req.body.GamesWon;
    User.findOneAndUpdate({ "Name": CurrentUserName }, { GamesWon: newGamesWon }, { new: true })
    .then(user => {
        console.log("WON UPDATED");
        res.json(user);
    })
    .catch(err => {
        console.log(err);
    });
});




app.put('/Server/UpdateRanks', async (req, res) => {
  User.find()
    .then(AllUsers => {
      const SortedUsers = AllUsers.sort((a, b) => {
       
        return a.BestTime - b.BestTime;
      });

      for (let i = 0; i < SortedUsers.length; i++) {
        const user = SortedUsers[i];
        User.updateOne({ _id: user._id }, { Rank: i + 1 })
          .then(() => console.log(" User rank updated successfully"))
          .catch(err => console.log("Error updating user rank: " + err));
      }
    })
    .catch(err => {
      console.error(err);
    });
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
